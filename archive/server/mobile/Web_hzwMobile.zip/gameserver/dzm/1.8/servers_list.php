{  
    "version": 1,
	"severVerson": "1.78.5",
	"updateAddress": "http://127.0.0.1/gameserver/dzm/1.8/.php",
	"rootAddress": "http://127.0.0.1/gameserver/dzm/1.8/update.php",
    "defaultSeverID" : 1,
    "announcement":"http://127.0.0.1/gameserver/dzm/1.8/notice_ios.php",
    "updateByteSize":0,
	"updateMsg": "转盘刷新显示问题修复",
	"serverInUpdate": "，预计停服时间为3个小时左右，如有疑问请联系客服QQ：126367",
	"serverInGray": "龙吟好，预计停服时间为3个小时左右，如有疑问请联系客服QQ：12367",
	"inStoreUpdate":"http://127.0.0.1/download/91/index_ios.html",

    "severs" :
    [
		{"id":1, "name":"A1-TEST" , "address":"127.0.0.1", "port":25524, "state":"new"}
    ]
} 
